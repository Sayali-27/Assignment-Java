 class Array
{ 
    public static void main(String args[])
    {
           int[] arr=new int[5];
            arr[0]=3;
            arr[1]=4;
            arr[2]=2;
            arr[4]=9;
            arr[4]=5;
            for(int i=0;i<5;i++)
             {
                   if(arr[i]%2!=0)
                      System.out.println(arr[i]);
              }
    }
 
}