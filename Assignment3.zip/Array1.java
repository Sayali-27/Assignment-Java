import java.util.Scanner;
 class Array1
{ 
    public static void main(String args[])
    {
           int[] arr=new int[5];
           int sum=0;
          Scanner sc =new Scanner(System.in);
          System.out.println("Enter array elements");
            for(int i=0;i<5;i++)
             {
                   
                    arr[i]=sc.nextInt( );
                    sum=sum+arr[i];
              }
         System.out.println("Sum of array elements is "+sum);
    }
 
}