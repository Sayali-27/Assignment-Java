import java.util.Scanner;
public class Avenger
{
     int age;
     String  name,power,weapon,planet;
   Scanner sc =new Scanner(System.in);
public void getDetails()
{
      
       System.out.print("Enter age");
        age=sc.nextInt( );

       System.out.print("Enter name");
        name=sc.nextLine( );
 
       System.out.print("Enter power");
        power=sc.nextLine( );
 
      System.out.print("Enter weapon");
        weapon=sc.nextLine( );

       System.out.print("Enter planet");
        planet=sc.nextLine( );
}
 public void displayDetails()
   {
          
      System.out.println("My name is "+name);
      System.out.println("My age is "+age);
      System.out.println("My power is "+power);
      System.out.println("My weapon is "+weapon);
      System.out.println("My planet is "+planet);
   }

   public static void main(String args[])
    {
        Avenger a[]=new Avanger[5];
       for(int i=0;i<5;i++)
      {
       a[i]=new Avenger();
       }
       for(int i=0;i<5;i++)
      {
        a[i].getDetails();
        a[i].displayDetails();
       }
    }
 
}